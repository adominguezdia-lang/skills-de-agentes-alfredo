# Anexo Técnico — Arquitectura Documental Hermes–LLM–BD para FASP

> Migrado del documento Word original. Fuente de verdad para la implementación del skill `fasp-document-pipeline`.

## 0. Arquitectura integrada de procesamiento con LLM–Python–ARS

La Evaluación Estratégica de Coordinación al **FASP** (Fondo de Aportaciones para la Seguridad Pública) se estructura en tres etapas secuenciales: análisis documental, trabajo de campo y análisis–recomendaciones, cada una asociada a un producto específico (Informe 1, Informe 2 e Informe Final) y a un conjunto de anexos técnicos definidos en los TdR.

La pila **LLM–Python–ARS** se diseña para funcionar como una columna de procesamiento de información que:

- Respeta íntegramente la metodología prevista en el Plan de Trabajo (Análisis normativo, ARS, teoría de grafos, triangulación).

- Inserta módulos LLM y scripts Python como servicios de procesamiento de documentos, transcripciones y redes.

- Evita retrabajos mediante el uso consistente de identificadores únicos y estructuras de datos reutilizables.

- Genera directamente los entregables esperados en los TdR (matrices, diccionarios, informes y fichas), bajo supervisión de los perfiles del equipo.

## 1. Propósito y alineación con el Plan de Trabajo

La Evaluación Estratégica de Coordinación al FASP se estructura en tres etapas secuenciales: análisis documental, trabajo de campo y análisis–recomendaciones, cada una asociada a un producto específico (Informe 1, Informe 2 e Informe Final) y a un conjunto de anexos técnicos definidos en los TdR.

La pila LLM–Python–ARS se diseña para funcionar como una columna de procesamiento de información que:

Respeta íntegramente la metodología prevista en el Plan de Trabajo (Análisis normativo, ARS, teoría de grafos, triangulación).

Inserta módulos LLM y scripts Python como servicios de procesamiento de documentos, transcripciones y redes.

Evita retrabajos mediante el uso consistente de identificadores únicos y estructuras de datos reutilizables.

Genera directamente los entregables esperados en los TdR (matrices, diccionarios, informes y fichas), bajo supervisión de los perfiles del equipo.

## 2. Etapa 1 – Análisis documental y Producto 1

Etapa del plan: Primera Etapa – Análisis documental.Producto TdR: Informe de Diagnóstico del Marco Normativo, Funcional y de Actores Preliminares.Anexos asociados: Anexo 1 (Ficha técnica FASP), Anexo 2 (Matriz de congruencia normativa), Anexo 3 (Directorio preliminar de actores).

**Módulos LLM**

### LLM-1 Parser jurídico–documental

Entradas: normas federales, estatales y municipales, convenios FASP, manuales, lineamientos.

**Tareas:**
 Extraer metadatos (nombre de norma, nivel de gobierno, jerarquía, vigencia).
 Segmentar en unidades normativas (artículos, fracciones) etiquetadas por tema de coordinación y etapa del ciclo (integración, distribución, administración, supervisión, seguimiento).
 Salida: tabla estructurada (CSV/JSON) con campos id_norma, nivel, jerarquía, artículo, tema, referencia a coordinación, que alimenta la matriz de congruencia.

### LLM-2 Constructor de matriz de congruencia

Entradas: salida del Parser jurídico.

**Tareas:**
 Clasificar cada unidad normativa por tipo de competencia (exclusiva, concurrente, complementaria) y dimensión del ciclo (planeación, asignación, ejecución, seguimiento, rendición de cuentas).
 Marcar nivel de obligatoriedad (mandatoria, facultativa, recomendatoria) y detectar duplicidades o posibles contradicciones normativas.
 Salida: Matriz de congruencia normativa (Anexo 2) en formato editable, que el equipo jurídico revisa y depura.

### LLM-3 Generador del directorio preliminar de actores

Entradas: normas clasificadas y convenios FASP.

**Tareas:**
 Identificar unidades administrativas federales y estatales con atribuciones en integración, distribución, administración, supervisión y seguimiento del FASP.
 Producir un listado estructurado con nombre oficial, nivel de gobierno, naturaleza del actor (formal/informal según norma), funciones principales.
 Salida: base de datos editable (CSV/XLSX) que constituye el Anexo 3 (Directorio preliminar de actores).

**Módulos Python/ARS**

### PY-1 Estructuración de bases normativas y de actores

**Tareas:**
 Asignar identificadores únicos (ID) a cada actor, consistentes con lo establecido en el procedimiento de trazabilidad hacia el sociograma.
 Generar la Ficha técnica del FASP (Anexo 1) empleando plantillas estructuradas y la información recopilada.
 Supervisión humana:La Coordinadora y el Analista Senior jurídico revisan y corrigen la matriz de congruencia y el directorio antes de cerrar el Producto 1, asegurando que el LLM haya respetado jerarquías normativas y categorías de coordinación.

## 3. Etapa 2 – Trabajo de campo, ARS y Producto 2

Etapa del plan: Segunda Etapa – Trabajo de campo.Producto TdR: Informe de Hallazgos de Campo y Grupos de Enfoque.Anexos asociados: Anexo 4 (Matriz de adyacencia), Anexo 5 (Memoria algorítmica), Anexo 6 (Diccionario de atributos de los nodos).

**Módulos LLM**

### LLM-4 Extractor de relaciones y atributos

Entradas: transcripciones de entrevistas semiestructuradas y grupos de enfoque, aplicadas a actores formales e informales en los tres niveles de gobierno.

**Tareas:**
 Reconocer actores mencionados (unidades, cargos, niveles de gobierno) y mapearlos a los IDs del directorio preliminar.
 Extraer relaciones: quién se coordina con quién, para qué etapa del FASP, con qué frecuencia y por qué canal.
 Etiquetar tipo de vínculo (formal/informal, jerárquico, operativo, consultivo) y construir una lista preliminar de aristas (edge list) con origen, destino, tipo de relación, peso (frecuencia/intensidad) y direccionalidad.
 Salida: edge list y diccionario de nodos en formato CSV/JSON, que serán revisados por el equipo ARS.

### LLM-5 Normalizador de nodos

Entradas: edge list preliminar y directorio de actores.

**Tareas:**
 Detectar potenciales duplicidades semánticas (nombre completo vs siglas, variantes de secretarías o fiscalías).
 Unificar criterios de identificación para garantizar que cada nodo corresponda a una única unidad administrativa.

**Módulos Python/ARS**

### PY-2 Constructor de matrices de red

Entradas: edge list validada y diccionario de nodos.

**Tareas:**
 Generar la Matriz de adyacencia (Actor–Actor) en formatos abiertos (CSV/XLSX) con ponderación de lazos según la escala de intensidad definida en la Memoria de Codificación.
 Construir la Matriz de incidencia (Actor–Proceso) que vincula actores con etapas del FASP, programas prioritarios y procesos críticos.
 Salida: Anexo 4 (Matriz de adyacencia) y estructuras complementarias para la memoria algorítmica.

### PY-3 Cálculo de métricas y Memoria algorítmica

**Tareas:**
 Calcular centralidad de grado (in-degree/out-degree), intermediación, cercanía y métricas globales de densidad, modularidad y diámetro, conforme a lo descrito en el Plan de Trabajo.
 Documentar algoritmos, parámetros y tratamiento de lazos no recíprocos y nodos aislados en la Memoria algorítmica (Anexo 5).
 Generar el Diccionario de atributos de nodos (Anexo 6) con metadatos: nivel de gobierno, naturaleza jurídica, rol en el ciclo del FASP, frecuencia y tipo de participación, etc.

### LLM-6 Redactor de hallazgos ARS

Entradas: métricas de red y sociogramas generados por Python/ARS.

**Tareas:**
 Producir borradores de secciones del Producto 2: análisis topológico de la red, descripción textual de sociogramas de gestión real, interpretación inicial de métricas de centralidad y densidad en términos de coordinación.
 Supervisión humana:El Analista Senior experto en redes y los Analistas Junior de grafos validan la edge list, matrices y métricas, ajustan la clasificación de relaciones y corrigen las interpretaciones redactadas por el LLM antes de cerrar el Producto 2.

## 4. Etapa 3 – Triangulación, recomendaciones y Producto 3

Etapa del plan: Tercera Etapa – Análisis y recomendaciones.Producto TdR: Informe Final y Estrategia de Consolidación del FASP.Anexos asociados: Anexo 7 (Glosario), Anexo 8 (Metodología de replicabilidad), Anexo 9 (Propuesta de modificación normativa), Anexo 10 (Hallazgos, recomendaciones y áreas de mejora), Anexo 11 (Ficha técnica administrativa), Anexo 12 (Fuentes de información).

**Módulos LLM**

### LLM-7 Triangulador asistido norma–red–campo

Entradas: matriz de congruencia normativa (Producto 1), resultados ARS (Producto 2) y resúmenes de entrevistas.

**Tareas:**
 Sugerir coincidencias y divergencias entre red formal (normativa) y red real (operativa).
 Proponer hipótesis de riesgos de coordinación (fallas estructurales, cuellos de botella, nodos críticos) que alimenten el Diagnóstico de riesgos de coordinación.
 Agrupar hallazgos en categorías temáticas (normativos, organizacionales, capacidades, canales de comunicación).

### LLM-8 Generador de fichas de hallazgos y recomendaciones

Entradas: listado priorizado de problemas y riesgos de coordinación.

**Tareas:**
 Redactar borradores de fichas de hallazgos y recomendaciones siguiendo la estructura de las tablas del Anexo 10 (verbo + producto/proceso a modificar + área de oportunidad + justificación + efecto esperado).
 Preparar insumos para el análisis de viabilidad (claridad, relevancia, justificación, factibilidad) conforme a los criterios SHCP.

### LLM-9 Redactor asistido del Informe Final

Entradas: diagnósticos normativos, resultados de ARS, fichas validadas.

**Tareas:**
 Elaborar borradores de las secciones del Producto 3: justificación metodológica global, síntesis analítica de triangulación, diagnóstico de riesgos de coordinación, propuesta de reformas normativas, propuesta de rediseño de lógicas operativas y recomendaciones finales.
 Generar el Glosario especializado (Anexo 7) y elementos textuales de la Metodología para la replicabilidad (Anexo 8), en coherencia con la Memoria algorítmica y el Diccionario de nodos.

**Módulos Python/ARS**

### PY-4 Exportación y soporte de replicabilidad

**Tareas:**
 Consolidar tablas de métricas, matrices y sociogramas en formatos abiertos para su inclusión como insumos del Informe Final y anexos.
 Documentar en un esquema reproducible los pasos de codificación, construcción de matrices y cálculo de métricas, alineado con el Anexo 8 (Metodología para la replicabilidad del ejercicio evaluativo).
 Supervisión humana:La Coordinadora y el equipo de análisis validan las triangulaciones, ajustan las recomendaciones y completan las fichas de ASM y la clasificación de viabilidad, garantizando que cada recomendación se derive directamente de la evidencia estructural y relacional obtenida.

## 5. Gobernanza de la pila y trazabilidad

Para asegurar que la arquitectura LLM–Python–ARS sea auditable y no altere la lógica metodológica:

Plantillas de entrada/salida: se diseñan formatos estándar para la carga de normas, transcripciones y edge lists, reutilizados en las tres etapas.

Checkpoints por perfil:

Etapa 1: revisión por Coordinadora y Analistas Senior jurídicos de la matriz de congruencia y directorio.

Etapa 2: validación por experto en redes y Analistas Junior de nodos, aristas y clasificación de relaciones.

Etapa 3: validación por Coordinación de evaluación de narrativas, diagnósticos y recomendaciones.

Trazabilidad: cada modificación se documenta en minutas y versiones de matrices, siguiendo el mecanismo de definiciones conjuntas y reuniones de seguimiento previsto con el SESNSP.
